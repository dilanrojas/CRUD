package vista.grafico;
/**
 * @author Ana
 * @date Nov 5, 2025
 * @version 1.0
 * @description Vista principal del menu donde se pueden ver las opciones disponibles.
 */
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuVista extends JFrame {

	private static final long serialVersionUID = 1L;
	// Componentes gráficos
	private JLabel lblMenu;
	private JButton btnActualizar;
	private JButton btnInsertar;
	private JButton btnEliminar;
	private JButton btnMostrar;
	private JButton btnConfig;
	private JButton btnSalir;

	// Main (Pruebas)
	public static void main(String[] args) {
		MenuVista menu = new MenuVista();
	}

	// Constructor
	public MenuVista() {
		getContentPane().setFont(new Font("Monospaced", Font.BOLD, 15));
		getContentPane().setBackground(new Color(204, 229, 255));
		initComponents();
		setTitle("MENÚ PRINCIPAL");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		
		btnSalir = new JButton("SALIR");
		btnSalir.setBounds(153, 377, 156, 29);
		getContentPane().add(btnSalir);
		setVisible(true);
	}

	// Inicializar componentes
	private void initComponents() {
		lblMenu = new JLabel("MENÚ PRINCIPAL");
		lblMenu.setFont(new Font("Monospaced", Font.BOLD, 20));
		lblMenu.setBounds(153, 59, 174, 37);
		getContentPane().add(lblMenu);

		btnActualizar = new JButton("ACTUALIZAR");
		btnActualizar.setFont(new Font("Monospaced", Font.BOLD, 15));
		btnActualizar.setBounds(156, 133, 153, 29);
		getContentPane().add(btnActualizar);

		btnInsertar = new JButton("INSERTAR");
		btnInsertar.setFont(new Font("Monospaced", Font.BOLD, 15));
		btnInsertar.setBounds(156, 186, 153, 29);
		getContentPane().add(btnInsertar);

		btnEliminar = new JButton("ELIMINAR");
		btnEliminar.setFont(new Font("Monospaced", Font.BOLD, 15));
		btnEliminar.setBounds(156, 238, 153, 29);
		getContentPane().add(btnEliminar);

		btnMostrar = new JButton("MOSTRAR");
		btnMostrar.setFont(new Font("Monospaced", Font.BOLD, 15));
		btnMostrar.setBounds(156, 289, 153, 29);
		getContentPane().add(btnMostrar);

		btnConfig = new JButton("CONFIGURACION");
		btnConfig.setFont(new Font("Monospaced", Font.BOLD, 15));
		btnConfig.setBounds(156, 337, 153, 29);
		getContentPane().add(btnConfig);
	}

	// Getters

	public JLabel getLblNewLabel() {
		return lblMenu;
	}

	public JButton getBtnActualizar() {
		return btnActualizar;
	}

	public JButton getBtnInsertar() {
		return btnInsertar;
	}

	public JButton getBtnEliminar() {
		return btnEliminar;
	}

	public JButton getBtnMostrar() {
		return btnMostrar;
	}

	public JButton getBtnConfig() {
		return btnConfig;
	}
	public JButton getBtnSalir() {
		return btnSalir;
	}

	// Configurar escuchadores
	public void setActionListener(ActionListener listener) {
		btnActualizar.addActionListener(listener);
		btnInsertar.addActionListener(listener);
		btnEliminar.addActionListener(listener);
		btnMostrar.addActionListener(listener);
		btnConfig.addActionListener(listener);
		btnSalir.addActionListener(listener);

		System.out.println("Vista - Menú listo para escuchar eventos");
	}

	// Método mostrar mensaje
	public void mostrarMsj(String msj) {
		JOptionPane.showMessageDialog(this, msj);
	}

	// Método cerrar
	public void cerrar() {
		System.out.println("CERRAR - Vista de Menú");
		dispose();
	}

}
