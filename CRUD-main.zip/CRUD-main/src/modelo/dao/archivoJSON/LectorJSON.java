package modelo.dao.archivoJSON;

/**
 * @author Dilan Rojas
 * @date Nov 7, 2025
 * @version 1.0
 * @description description
 */

public class LectorJSON {

}
